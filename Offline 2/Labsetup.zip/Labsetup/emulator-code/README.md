# Generate the Container Files

Instructors who are interested in generating their customized
Internet emulator can use the Python program in this folder. 

Run the `internet-nano.py` or `internet-mini.py` to generate the container files.
Each program will create a folder called `output`, which stores
the container files for the emulation. 

