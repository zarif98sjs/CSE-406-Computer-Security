export let Configuration = {
    ApiPath: '/api/v1'
};