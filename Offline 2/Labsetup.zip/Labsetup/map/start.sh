#!/bin/sh
cd /usr/src/app/backend
while true; do node ./bin/main.js; done
