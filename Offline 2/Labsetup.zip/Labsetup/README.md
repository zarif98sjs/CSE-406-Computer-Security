# Lab setup for the Morris Worm Lab

- `worm/`: contains the provided skeleton worm code. 
- `internet-mini/`: contains the mini Internet emulation files.
- `internet-nano/`: contains the nano Internet emulation files. 
- `map/`: contains the Map application container (for network visualization).   
- `emulator-code/`: contains the Python code to generate the emulation files. 
- `shellcode/`: contains the source code of the Shellcode.

